import { defineStore } from 'pinia'
import { ref } from 'vue'
import {
  buildEntityExtractMessages,
  buildFixMessages,
  buildSegmentFillMessages,
  buildStage1Messages,
  buildStage2Messages
} from '@/core/llm/prompts'
import { useProviderStore } from './provider'
import type { EntityKind, EntityType } from '@/domain/types'
import type {
  Beat,
  Entity,
  FieldSchema,
  ProjectSettings,
  SeamAnalysis
} from '@/domain/types'
import type {
  FixInput,
  FixPatch,
  SegmentFillInput,
  Stage1Beat,
  Stage1NewEntity,
  Stage2BeatDetail
} from '@/core/llm/prompts'

export interface FixResult {
  patches: FixPatch[]
  unfixable: string[]
  notes: string
}

/** 阶段三的单段补全任务 */
export interface SegmentFillTask {
  id: string
  schema: FieldSchema[]
  beats: Beat[]
  entities: Entity[]
  seamFromPrev: SeamAnalysis | null
  nextSeam: SeamAnalysis | null
  /** 已算好的字段（含派生字段），交给模型当只读上下文 */
  existing: Record<string, string>
  frames: number
  index: number
}

export interface Stage1Result {
  beats: Stage1Beat[]
  newEntities: EntityProposal[]
}

export interface EntityProposal extends Stage1NewEntity {
  accepted: boolean
  /** 已存在于注册表，不可重复创建 */
  exists: boolean
  /** 本批片段里实际被引用了几次 */
  refCount: number
}

function toStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return []
  return value
    .map((x) => (typeof x === 'string' ? x.trim() : ''))
    .filter((x) => !!x)
}

const TYPE_SET: EntityType[] = ['character', 'scene', 'prop', 'ui', 'other']

/** 清理模型返回的实体草案：去重、过滤已知实体、补默认值 */
function normalizeProposals(
  raw: unknown,
  known: Set<string>,
  beats: Stage1Beat[]
): EntityProposal[] {
  const list = Array.isArray(raw) ? (raw as Stage1NewEntity[]) : []
  const refCount = new Map<string, number>()
  const sceneNames = new Set<string>()
  for (const b of beats) {
    for (const name of [...(b.entities ?? []), ...(b.speaker ? [b.speaker] : [])]) {
      refCount.set(name, (refCount.get(name) ?? 0) + 1)
    }
    if (b.scene) {
      refCount.set(b.scene, (refCount.get(b.scene) ?? 0) + 1)
      sceneNames.add(b.scene)
    }
  }

  const seen = new Set<string>()
  const out: EntityProposal[] = []
  for (const item of list) {
    const name = String(item?.name ?? '').trim()
    if (!name || seen.has(name)) continue
    seen.add(name)
    const exists = known.has(name)
    // 被当成场景引用的名字，类型强制归正为 scene
    const forceScene = sceneNames.has(name)
    const kind: EntityKind = forceScene
      ? 'non_speaking'
      : item?.kind === 'speaking'
        ? 'speaking'
        : 'non_speaking'
    const type: EntityType = forceScene
      ? 'scene'
      : TYPE_SET.includes(item?.type as EntityType)
        ? (item.type as EntityType)
        : 'character'
    out.push({
      name,
      type,
      kind,
      voiceDesc: kind === 'speaking' ? String(item?.voiceDesc ?? '').trim() : '',
      textDesc: String(item?.textDesc ?? '').trim(),
      note: String(item?.note ?? '').trim(),
      firstAppear: item?.firstAppear ? String(item.firstAppear).trim() : '',
      accepted: !exists,
      exists,
      refCount: refCount.get(name) ?? 0
    })
  }

  // 模型漏登记但被片段引用的名字，也补进草案，避免绑定悬空
  for (const [name, count] of refCount) {
    if (known.has(name) || seen.has(name)) continue
    seen.add(name)
    const isScene = sceneNames.has(name)
    const isSpeaker = !isScene && beats.some((b) => b.speaker === name)
    out.push({
      name,
      type: isScene ? 'scene' : 'character',
      kind: isSpeaker ? 'speaking' : 'non_speaking',
      voiceDesc: '',
      textDesc: '',
      note: isScene ? '模型未登记的场景，由片段引用反推' : '模型未登记，由片段引用反推',
      firstAppear: '',
      accepted: true,
      exists: false,
      refCount: count
    })
  }

  return out
}

export const usePipelineStore = defineStore('pipeline', () => {
  const running = ref(false)
  const progress = ref('')
  const error = ref<string | null>(null)

  function requireProvider() {
    const provider = useProviderStore()
    const hasKey = provider.providers.some((p) => p.baseUrl && p.model)
    if (!hasKey) throw new Error('请先在设置中配置模型供应商')
    return provider
  }

  /* --------------------------- 阶段一 --------------------------- */

  async function runStage1(
    story: string,
    entityNames: string[]
  ): Promise<Stage1Result> {
    const provider = requireProvider()
    running.value = true
    error.value = null
    progress.value = '阶段一：正在拆解分镜并登记实体…'
    try {
      const data = await provider.callJson<{
        beats: Stage1Beat[]
        newEntities?: Stage1NewEntity[]
      }>(buildStage1Messages(story, entityNames), { temperature: 0.35 })

      const raw = Array.isArray(data?.beats) ? data.beats : []
      if (!raw.length) throw new Error('模型没有返回任何分镜片段')

      const beats = raw.map((b) => ({
        title: String(b.title ?? '').trim() || '未命名片段',
        kind: String(b.kind ?? 'action').trim(),
        dialogue: b.dialogue != null ? String(b.dialogue).trim() : undefined,
        scene: b.scene ? String(b.scene).trim() : undefined,
        entities: toStringArray(b.entities),
        speaker: b.speaker ? String(b.speaker).trim() : undefined
      }))

      const known = new Set(entityNames)
      const newEntities = normalizeProposals(data?.newEntities, known, beats)

      return { beats, newEntities }
    } catch (e) {
      error.value = (e as Error).message
      throw e
    } finally {
      running.value = false
      progress.value = ''
    }
  }

  /** 只梳理实体，不拆片段 */
  async function runEntityExtract(story: string, entityNames: string[]): Promise<EntityProposal[]> {
    const provider = requireProvider()
    running.value = true
    error.value = null
    progress.value = '正在梳理实体…'
    try {
      const data = await provider.callJson<{ newEntities?: Stage1NewEntity[] }>(
        buildEntityExtractMessages(story, entityNames),
        { temperature: 0.35 }
      )
      const known = new Set(entityNames)
      return normalizeProposals(data?.newEntities, known, [])
    } catch (e) {
      error.value = (e as Error).message
      throw e
    } finally {
      running.value = false
      progress.value = ''
    }
  }

  /* --------------------------- 阶段二 --------------------------- */

  async function runStage2(
    beats: Beat[],
    entities: Entity[]
  ): Promise<Stage2BeatDetail[]> {
    const provider = requireProvider()
    running.value = true
    error.value = null
    progress.value = `阶段二：正在填充 ${beats.length} 个片段的细节…`
    try {
      const data = await provider.callJson<{ details: Stage2BeatDetail[] }>(
        buildStage2Messages(beats, entities),
        { temperature: 0.4 }
      )
      const details = Array.isArray(data?.details) ? data.details : []
      if (!details.length) throw new Error('模型没有返回任何细节')
      return details
    } catch (e) {
      error.value = (e as Error).message
      throw e
    } finally {
      running.value = false
      progress.value = ''
    }
  }

  /* --------------------------- 阶段三 --------------------------- */

  /**
   * 阶段三：为单个视频段补全所有需要模型填写的字段。
   * 返回 { 字段名: 内容 }，由调用方决定怎么写回 store。
   */
  async function runSegmentFill(
    input: Omit<SegmentFillInput, 'fps'> & { fps?: number },
    settings: ProjectSettings
  ): Promise<Record<string, string>> {
    const provider = requireProvider()
    const data = await provider.callJson<Record<string, unknown>>(
      buildSegmentFillMessages({ ...input, fps: input.fps ?? settings.fps }),
      { temperature: 0.5 }
    )

    const targets = input.schema.filter((f) => f.source === 'llm')
    const out: Record<string, string> = {}
    for (const f of targets) {
      const value = data?.[f.key]
      if (value == null) continue
      const text = typeof value === 'string' ? value.trim() : String(value).trim()
      if (text) out[f.key] = text
    }
    if (!Object.keys(out).length) {
      throw new Error('模型没有返回任何可用的字段内容')
    }
    return out
  }

  /**
   * 批量补全。并发受控，逐段回调，单段失败不影响其他段。
   */
  async function fillSegments(
    tasks: SegmentFillTask[],
    settings: ProjectSettings,
    onOne: (taskId: string, fields: Record<string, string>, err?: string) => void | Promise<void>,
    concurrency = 2
  ): Promise<{ ok: number; failed: number }> {
    running.value = true
    error.value = null

    const total = tasks.length
    let cursor = 0
    let ok = 0
    let failed = 0
    let finished = 0

    async function worker() {
      for (;;) {
        const i = cursor++
        if (i >= total) return
        const task = tasks[i]
        progress.value = `阶段三：正在补全 ${finished + 1}/${total} 段…`
        try {
          const fields = await runSegmentFill(
            {
              schema: task.schema,
              groupBeats: task.beats,
              entities: task.entities,
              seamFromPrev: task.seamFromPrev,
              nextSeam: task.nextSeam,
              existing: task.existing,
              segmentIndex: task.index,
              segmentTotal: total,
              frames: task.frames
            },
            settings
          )
          await onOne(task.id, fields)
          ok++
        } catch (e) {
          failed++
          await onOne(task.id, {}, (e as Error).message)
        }
        finished++
        progress.value = `阶段三：已完成 ${finished}/${total} 段…`
      }
    }

    try {
      await Promise.all(Array.from({ length: Math.min(concurrency, Math.max(1, total)) }, () => worker()))
    } finally {
      running.value = false
      progress.value = ''
    }

    if (failed) error.value = `${failed} 段补全失败，详见列表标记`
    return { ok, failed }
  }

  /* --------------------------- 错误修复 --------------------------- */

  /**
   * 交付前修复：把校验出的问题交给模型，返回需要改写的字段。
   * 只接收 scope === 'field' 的问题，结构性问题由调用方拦在外面。
   */
  async function runFix(
    input: Omit<FixInput, 'fps'> & { fps?: number },
    settings: ProjectSettings
  ): Promise<FixResult> {
    const provider = requireProvider()
    running.value = true
    error.value = null
    progress.value = '正在修复校验问题…'
    try {
      const data = await provider.callJson<{
        patches?: unknown
        unfixable?: unknown
        notes?: unknown
      }>(buildFixMessages({ ...input, fps: input.fps ?? settings.fps }), { temperature: 0.25 })

      const validKeys = new Set(input.schema.map((f) => f.key))
      const patches: FixPatch[] = []
      if (Array.isArray(data?.patches)) {
        for (const raw of data.patches as Array<Record<string, unknown>>) {
          const field = String(raw?.field ?? '').trim()
          if (!field || !validKeys.has(field)) continue
          const value = typeof raw?.value === 'string' ? raw.value : ''
          if (!value.trim()) continue
          patches.push({
            field,
            value,
            reason: String(raw?.reason ?? '').trim()
          })
        }
      }

      const unfixable = Array.isArray(data?.unfixable)
        ? (data.unfixable as unknown[]).map((x) => String(x)).filter(Boolean)
        : []
      const notes = String(data?.notes ?? '').trim()

      if (!patches.length && !unfixable.length) {
        throw new Error('模型没有给出任何修改')
      }
      return { patches, unfixable, notes }
    } catch (e) {
      error.value = (e as Error).message
      throw e
    } finally {
      running.value = false
      progress.value = ''
    }
  }

  function reset() {
    running.value = false
    progress.value = ''
    error.value = null
  }

  return {
    running,
    progress,
    error,
    runStage1,
    runEntityExtract,
    runStage2,
    runSegmentFill,
    fillSegments,
    runFix,
    reset
  }
})
