<script setup lang="ts">
import { computed } from 'vue'
import type { Entity, ID, SeamAnalysis } from '@/domain/types'

const props = defineProps<{
  seam: SeamAnalysis
  index: number
  entityById: Map<ID, Entity>
}>()

function label(id: ID | null | undefined): string {
  if (!id) return '—'
  const e = props.entityById.get(id)
  if (!e) return id
  return `${e.name}${e.subjectN != null ? ` (S${e.subjectN})` : ''}`
}

const mode = computed(() => {
  if (props.seam.blackFallback) return 'black'
  if (props.seam.needsTailCut) return 'cut'
  return 'aligned'
})

const modeText = computed(
  () =>
    ({
      black: '黑屏兜底',
      cut: '尾帧切镜',
      aligned: '直接顺接'
    })[mode.value]
)
</script>

<template>
  <div class="seam-card" :class="{ 'is-black': mode === 'black', 'is-cut': mode === 'cut' }">
    <div class="row-between">
      <div class="row" style="gap: 6px">
        <span class="mono muted" style="font-size: 11.5px">缝合点 {{ index }} → {{ index + 1 }}</span>
        <span
          class="tag-chip"
          :style="{
            background: mode === 'black' ? '#fdf0dc' : mode === 'cut' ? '#e7f0ff' : '#e9f7ef',
            color: mode === 'black' ? '#8a6008' : mode === 'cut' ? '#2b56b8' : '#217a52'
          }"
        >
          {{ modeText }}
        </span>
      </div>
      <div class="row" style="gap: 6px">
        <span class="tag-chip" :style="{ background: '#f2f4f7', color: '#5b6273' }">
          continuityToNext: {{ seam.continuityToNext }}
        </span>
        <span class="tag-chip" :style="{ background: '#f2f4f7', color: '#5b6273' }">
          continuityFromPrev: {{ seam.continuityFromPrev }}
        </span>
      </div>
    </div>

    <div class="mono" style="margin-top: 8px; font-size: 12px; line-height: 1.8">
      <div>左段末帧主体　<span style="color: #2b56b8">{{ label(seam.lastSubjectId) }}</span></div>
      <div>右段首帧主体　<span style="color: #2b56b8">{{ label(seam.firstSubjectId) }}</span></div>
      <div>右段首个说话人　<span style="color: #217a52">{{ label(seam.firstSpeakerId) }}</span></div>
      <div>
        尾帧切镜目标　
        <span :style="{ color: seam.needsTailCut ? '#2b56b8' : '#9aa1ad' }">
          {{ seam.needsTailCut ? label(seam.tailCutTargetId) : '不需要' }}
        </span>
      </div>
      <div>预备镜头　<span :style="{ color: seam.needsPreshoot ? '#217a52' : '#9aa1ad' }">{{ seam.needsPreshoot ? '需要 0.3s' : '不需要' }}</span></div>
    </div>

    <div v-if="seam.issues.length" class="stack" style="gap: 4px; margin-top: 8px">
      <div v-for="(i, k) in seam.issues" :key="k" class="issue" :class="i.level">{{ i.message }}</div>
    </div>
  </div>
</template>
