import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import { db, kvSet, saveOne } from '@/db'
import { uid, now } from '@/core/id'
import {
  assemble,
  defaultStrategy,
  makeGroup,
  newAssembly,
  type AssembleReport
} from '@/domain/assembler'
import { analyzeSeam, materializeSegment } from '@/domain/seam'
import { beatFrames } from '@/domain/timing'
import { deriveFields, makeSeeders, composeSegmentText } from '@/domain/derive'
import type {
  Assembly,
  AssemblyMode,
  Beat,
  Entity,
  FieldSchema,
  Group,
  ID,
  ProjectSettings,
  SeamAnalysis,
  Segment
} from '@/domain/types'
import { AUTO_KINDS, DEFAULT_SETTINGS } from '@/domain/types'
import { validateSegment, validateGlobal, type RuleIssue } from '@/domain/rules'

export interface SegmentView {
  group: Group
  /** 纯叙事片段 */
  narrativeBeats: Beat[]
  /** 素材化后的片段（含 preshoot / tail_cut / black） */
  beats: Beat[]
  frames: number
  over: boolean
  seam: SeamAnalysis | null
  nextSeam: SeamAnalysis | null
  fields: Record<string, string>
  issues: RuleIssue[]
}

export const useAssemblyStore = defineStore('assembly', () => {
  const assemblies = ref<Assembly[]>([])
  const currentId = ref<ID | null>(null)
  const loading = ref(false)

  /** 各方案的组级手工编辑覆盖 */
  const fieldOverrides = ref<Record<string, Record<string, string>>>({})
  const summaries = ref<Record<string, string>>({})

  const current = computed(() => assemblies.value.find((a) => a.id === currentId.value) ?? null)

  async function load(projectId: ID) {
    loading.value = true
    try {
      assemblies.value = await db.assemblies.where('projectId').equals(projectId).toArray()
      currentId.value = assemblies.value[0]?.id ?? null
      const kv = await db.kv.get(`overrides:${projectId}`)
      fieldOverrides.value = (kv?.value as Record<string, Record<string, string>>) ?? {}
      const kv2 = await db.kv.get(`summaries:${projectId}`)
      summaries.value = (kv2?.value as Record<string, string>) ?? {}
    } finally {
      loading.value = false
    }
  }

  function reset() {
    assemblies.value = []
    currentId.value = null
    fieldOverrides.value = {}
    summaries.value = {}
  }

  async function persistOverrides(projectId: ID) {
    await kvSet(`overrides:${projectId}`, fieldOverrides.value)
    await kvSet(`summaries:${projectId}`, summaries.value)
  }

  /* --------------------------- 方案管理 --------------------------- */

  async function createAssembly(
    projectId: ID,
    name: string,
    mode: AssemblyMode,
    beats: Beat[],
    settings: ProjectSettings = DEFAULT_SETTINGS,
    entityById?: Map<ID, Entity>
  ): Promise<AssembleReport & { assembly: Assembly }> {
    const cfg = defaultStrategy(settings, mode)
    const report = assemble(beats, cfg, { settings, entityById })
    const assembly = newAssembly(projectId, name, report.groups, cfg)
    await saveOne(db.assemblies, assembly)
    assemblies.value = [...assemblies.value, assembly]
    currentId.value = assembly.id
    return { ...report, assembly }
  }

  async function regenerate(
    assemblyId: ID,
    beats: Beat[],
    settings: ProjectSettings = DEFAULT_SETTINGS,
    entityById?: Map<ID, Entity>
  ) {
    const asm = assemblies.value.find((a) => a.id === assemblyId)
    if (!asm) return null
    const report = assemble(beats, asm.strategy, { settings, entityById })
    const next = { ...asm, groups: report.groups, updatedAt: now() }
    await saveOne(db.assemblies, next)
    assemblies.value = assemblies.value.map((a) => (a.id === assemblyId ? next : a))
    return report
  }

  async function updateStrategy(assemblyId: ID, patch: Partial<Assembly['strategy']>) {
    const asm = assemblies.value.find((a) => a.id === assemblyId)
    if (!asm) return
    const next = {
      ...asm,
      strategy: { ...asm.strategy, ...patch, weights: { ...asm.strategy.weights, ...(patch.weights ?? {}) } },
      updatedAt: now()
    }
    await saveOne(db.assemblies, next)
    assemblies.value = assemblies.value.map((a) => (a.id === assemblyId ? next : a))
  }

  async function renameAssembly(assemblyId: ID, name: string) {
    const asm = assemblies.value.find((a) => a.id === assemblyId)
    if (!asm) return
    const next = { ...asm, name, updatedAt: now() }
    await saveOne(db.assemblies, next)
    assemblies.value = assemblies.value.map((a) => (a.id === assemblyId ? next : a))
  }

  async function removeAssembly(assemblyId: ID) {
    await db.assemblies.delete(assemblyId)
    assemblies.value = assemblies.value.filter((a) => a.id !== assemblyId)
    if (currentId.value === assemblyId) currentId.value = assemblies.value[0]?.id ?? null
  }

  async function setGroups(assemblyId: ID, groups: Group[]) {
    const asm = assemblies.value.find((a) => a.id === assemblyId)
    if (!asm) return
    const next = { ...asm, groups, updatedAt: now() }
    await saveOne(db.assemblies, next)
    assemblies.value = assemblies.value.map((a) => (a.id === assemblyId ? next : a))
  }

  /* ------------------------- 手工调整分组 ------------------------- */

  async function splitGroupAt(assemblyId: ID, groupId: ID, atIndex: number, beats: Beat[]) {
    const asm = assemblies.value.find((a) => a.id === assemblyId)
    if (!asm) return
    const idx = asm.groups.findIndex((g) => g.id === groupId)
    if (idx < 0) return
    const g = asm.groups[idx]
    if (atIndex <= 0 || atIndex >= g.beatIds.length) return
    const left: Group = { ...g, beatIds: g.beatIds.slice(0, atIndex) }
    const right: Group = { id: uid('grp'), beatIds: g.beatIds.slice(atIndex) }
    const groups = [...asm.groups]
    groups.splice(idx, 1, left, right)
    await setGroups(assemblyId, groups)
    void beats
  }

  async function mergeGroups(
    assemblyId: ID,
    groupIds: ID[],
    beats: Beat[],
    settings: ProjectSettings = DEFAULT_SETTINGS
  ) {
    const asm = assemblies.value.find((a) => a.id === assemblyId)
    if (!asm) return { ok: false, frames: 0 }
    const indexes = groupIds
      .map((id) => asm.groups.findIndex((g) => g.id === id))
      .filter((i) => i >= 0)
      .sort((a, b) => a - b)
    if (indexes.length < 2) return { ok: false, frames: 0 }
    const merged: Group = {
      id: uid('grp'),
      beatIds: indexes.flatMap((i) => asm.groups[i].beatIds)
    }
    const groups = [...asm.groups]
    groups.splice(indexes[0], indexes.length, merged)
    await setGroups(assemblyId, groups)
    return { ok: true, frames: countFramesFromIds(merged.beatIds, beats, settings) }
  }

  function countFramesFromIds(ids: ID[], beats: Beat[], settings: ProjectSettings) {
    const byId = new Map(beats.map((b) => [b.id, b]))
    return ids.reduce((sum, id) => {
      const b = byId.get(id)
      return sum + (b ? beatFrames(b, settings) : 0)
    }, 0)
  }

  /** 把一个 Beat 移出分组（删除） */
  async function removeBeatFromGroup(assemblyId: ID, groupId: ID, beatId: ID) {
    const asm = assemblies.value.find((a) => a.id === assemblyId)
    if (!asm) return
    const groups = asm.groups
      .map((g) => (g.id === groupId ? { ...g, beatIds: g.beatIds.filter((b) => b !== beatId) } : g))
      .filter((g) => g.beatIds.length > 0)
    await setGroups(assemblyId, groups)
  }

  /* --------------------------- 段视图派生 --------------------------- */

  function buildSegmentViews(
    assembly: Assembly,
    beats: Beat[],
    settings: ProjectSettings,
    entityById: Map<ID, Entity>,
    schema: FieldSchema[]
  ): SegmentView[] {
    const byId = new Map(beats.map((b) => [b.id, b]))
    const seeder = makeSeeders(entityById)

    const rawGroups = assembly.groups
      .map((g) => ({
        group: g,
        narrative: g.beatIds.map((id) => byId.get(id)).filter(Boolean) as Beat[]
      }))
      .filter((x) => x.narrative.length > 0)

    // 先算全部缝合点
    const seams: Array<SeamAnalysis | null> = rawGroups.map((x, i) =>
      i === 0
        ? null
        : analyzeSeam(rawGroups[i - 1].narrative, x.narrative, { settings, entityById })
    )

    return rawGroups.map((x, i) => {
      const seam = seams[i]
      const nextSeam = i + 1 < seams.length ? seams[i + 1] : null

      // 材料化：本段是否需要黑屏/尾帧切镜取决于"与下一段"的缝合结论
      const material = materializeSegment(x.narrative, nextSeam, { settings, entityById })

      // ★ summary 存在独立的 summaries 表里，必须合并进字段包，
      //   否则校验会一直报"summary 为空"，导出也拿不到。
      const bag: Record<string, string> = { ...(fieldOverrides.value[x.group.id] ?? {}) }
      const summary = summaries.value[x.group.id]
      if (summary) bag.summary = summary

      const derived = deriveFields(schema, material.beats, bag, { settings, entityById, seeder })

      const issues = validateSegment(
        {
          beats: material.beats,
          narrativeBeats: x.narrative,
          fields: derived,
          seam,
          nextSeam
        },
        { settings, entityById, schema }
      )

      return {
        group: x.group,
        narrativeBeats: x.narrative,
        beats: material.beats,
        frames: material.frames,
        over: material.frames > settings.maxSegmentFrames,
        seam,
        nextSeam,
        fields: derived,
        issues
      }
    })
  }

  function globalIssues(
    views: SegmentView[],
    entities: Entity[],
    beats: Beat[],
    settings: ProjectSettings,
    entityById: Map<ID, Entity>,
    schema: FieldSchema[]
  ) {
    return validateGlobal(
      {
        entities,
        beats,
        segments: views.map((v) => ({ beats: v.beats, fields: v.fields }))
      },
      { settings, entityById, schema }
    )
  }

  /* --------------------------- 字段编辑 --------------------------- */

  async function setField(projectId: ID, groupId: ID, key: string, value: string) {
    if (!fieldOverrides.value[groupId]) fieldOverrides.value[groupId] = {}
    fieldOverrides.value[groupId][key] = value
    await persistOverrides(projectId)
  }

  async function setFields(projectId: ID, groupId: ID, values: Record<string, string>) {
    fieldOverrides.value[groupId] = { ...(fieldOverrides.value[groupId] ?? {}), ...values }
    await persistOverrides(projectId)
  }

  async function setSummary(projectId: ID, groupId: ID, value: string) {
    summaries.value[groupId] = value
    await persistOverrides(projectId)
  }

  /** 清除某些字段的人工锁定，恢复自动派生 */
  async function clearFields(projectId: ID, groupId: ID, keys: string[]) {
    const bag = fieldOverrides.value[groupId]
    if (bag) {
      for (const k of keys) delete bag[k]
      if (!Object.keys(bag).length) delete fieldOverrides.value[groupId]
    }
    await persistOverrides(projectId)
  }

  /** 单独清除 summary */
  async function clearSummary(projectId: ID, groupId: ID) {
    delete summaries.value[groupId]
    await persistOverrides(projectId)
  }

  function getSummary(groupId: ID): string {
    return summaries.value[groupId] ?? ''
  }

  /** 某个字段是否被人工改动锁定（锁定后引擎不再自动派生） */
  function isFieldLocked(groupId: ID, key: string): boolean {
    if (key === 'summary') return !!summaries.value[groupId]
    const bag = fieldOverrides.value[groupId]
    return !!bag && Object.prototype.hasOwnProperty.call(bag, key)
  }

  function lockedKeys(groupId: ID): string[] {
    const keys = Object.keys(fieldOverrides.value[groupId] ?? {})
    if (summaries.value[groupId]) keys.push('summary')
    return keys
  }

  function exportAssembly(
    views: SegmentView[],
    schema: FieldSchema[],
    settings: ProjectSettings = DEFAULT_SETTINGS
  ): string {
    const segments = views.map((v, i) => {
      const fields = { ...v.fields }
      const summary = summaries.value[v.group.id]
      if (summary) fields.summary = summary
      return {
        index: i + 1,
        frames: v.frames,
        duration: Number((v.frames / settings.fps).toFixed(3)),
        continuityFromPrev: v.seam?.continuityFromPrev ?? false,
        continuityToNext: v.nextSeam?.continuityToNext ?? false,
        blackFallback: v.nextSeam?.blackFallback ?? false,
        tailCutTo: v.nextSeam?.needsTailCut ? v.nextSeam.tailCutTargetId : null,
        beats: v.beats.map((b) => ({
          kind: b.kind,
          title: b.title,
          entities: b.entities,
          speakerId: b.speakerId ?? null
        })),
        fields,
        text: composeSegmentText(schema, fields)
      }
    })
    return JSON.stringify({ segments }, null, 2)
  }

  async function clearSegments(projectId: ID) {
    await db.kv.delete(`overrides:${projectId}`)
    await db.kv.delete(`summaries:${projectId}`)
    fieldOverrides.value = {}
    summaries.value = {}
  }

  return {
    assemblies,
    currentId,
    current,
    loading,
    fieldOverrides,
    summaries,
    load,
    reset,
    createAssembly,
    regenerate,
    updateStrategy,
    renameAssembly,
    removeAssembly,
    setGroups,
    splitGroupAt,
    mergeGroups,
    removeBeatFromGroup,
    buildSegmentViews,
    globalIssues,
    setField,
    setFields,
    setSummary,
    clearFields,
    clearSummary,
    getSummary,
    isFieldLocked,
    lockedKeys,
    exportAssembly,
    clearSegments,
    countFramesFromIds
  }
})
