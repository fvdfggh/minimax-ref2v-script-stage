import specText from '../../../说明.txt?raw'
import type { Beat, Entity, FieldSchema, SeamAnalysis } from '@/domain/types'
import { subjectTag, sxTag } from '@/domain/registry'
import { BEAT_KIND_LABEL, resolveSubjectId } from '@/domain/beats'
import type { ChatMessage } from './types'

/* ------------------------------------------------------------------ *
 * 三阶段提示词
 *   阶段一：故事 -> Beat 标题（台词为纯台词）
 *   阶段二：已确认的 Beat -> 填充细节
 *   阶段三：组合好的段 -> summary
 * ------------------------------------------------------------------ */

export const SPEC_TEXT = specText

const BASE_SYSTEM = `你是一个影视分镜与提示词工程助手，服务于 MiniMax H3 Ref2VA 多段拼接视频生成。
下面的团队规范文档是你唯一的判定依据，必须严格遵守：

<spec>
${specText}
</spec>

输出必须是合法 JSON，不要输出任何解释文字或 Markdown 代码块标记。`

/* --------------------------- 阶段一 --------------------------- */

export interface Stage1Beat {
  title: string
  kind: string
  dialogue?: string
  /** 本片段涉及的实体名（来自已知清单或 newEntities） */
  entities?: string[]
  /** 台词片段的说话人实体名 */
  speaker?: string
}

export type ProposedEntityType = 'character' | 'scene' | 'prop' | 'ui' | 'other'

export interface Stage1NewEntity {
  name: string
  type: ProposedEntityType
  kind: 'speaking' | 'non_speaking'
  /** 会说话角色必须给出固定音色描述，后续跨段逐字复用 */
  voiceDesc?: string
  /** 无图实体的纯文本视觉描述 */
  textDesc?: string
  /** 该实体在故事中的说明，便于人工核对 */
  note?: string
  /** 首次出现的大致位置说明 */
  firstAppear?: string
}

export function buildStage1Messages(
  story: string,
  knownEntityNames: string[],
  options: { language?: 'zh' | 'en' } = {}
): ChatMessage[] {
  const lang = options.language ?? 'zh'
  return [
    {
      role: 'system',
      content: `${BASE_SYSTEM}

现在是【阶段一：分镜拆解 + 实体登记】。
任务分两件，一次做完：
  A. 把故事拆成最小原子片段（Beat），每个 Beat 对应一个镜头，只做一件事；
  B. 同时把故事里出现过的实体（角色、场景、道具、界面）登记出来，并让每个 Beat 绑定它涉及的实体。

── A. 拆解规则 ──
1. 一个 Beat 只做一件事：一个动作 / 一次场景切换 / 一句台词 / 一个铺垫 / 一个反应 / 一个特写。
2. 台词必须与动作、场景切换完全分开。台词 Beat 的 dialogue 字段只写纯台词本身：
   - 不要写角色名，不要写引号，不要写 <d> 标签，不要写任何格式标记。
   - 例：dialogue: "我不信这世上没有解药。"
3. 动作与场景切换用 title 描述，dialogue 留空。
4. kind 只能取：dialogue、action、scene_switch、establishing、reaction、insert。
5. 过长就拆细：一个动作 Beat 建议不超过 3 秒；一句台词 Beat 建议不超过 5 秒。
6. title 用${lang === 'zh' ? '中文' : '英文'}，简洁一句话；不要出现镜头编号与时间戳。
7. 不要臆造故事里没有的情节，保持原有顺序与因果。

── B. 实体与绑定规则 ──
8. 每个 Beat 必须给出 entities 数组，列出该镜头里出现或涉及的实体名，至少 1 个，不得为空。
9. 台词 Beat 必须额外给出 speaker，它的值必须同时出现在 entities 里，且该实体必须是 kind = speaking。
10. 实体名必须与"已知实体"或你在 newEntities 里声明的名字完全一致，不允许出现第三种写法。
11. 会说话的角色：只要在故事里发过声，kind 填 speaking，并必须给出固定音色描述 voiceDesc：
    - 英文，一句话，形如 "speaking with a young male voice, slightly hoarse, tired but determined"
    - 不要带 (Sx) 后缀，编号由系统分配
    - 同一角色全片只描述一次，后续复用
12. 不说话的角色、场景、道具、界面：kind 填 non_speaking，不要写 voiceDesc。
13. 实体尽量给 textDesc：英文，描述它的外观特征，用于无参考图时的画面描述。
14. 已经存在、无需新建的实体不要放进 newEntities，但可以正常在 entities 里引用。

已知实体（可直接引用，不要重复放进 newEntities）：
${knownEntityNames.length ? knownEntityNames.join('、') : '（暂无）'}

输出 JSON 结构：
{
  "beats": [
    {
      "title": "字符串",
      "kind": "dialogue|action|scene_switch|establishing|reaction|insert",
      "dialogue": "纯台词，非台词片段省略此字段",
      "entities": ["实体名"],
      "speaker": "实体名，仅台词片段需要"
    }
  ],
  "newEntities": [
    {
      "name": "实体名",
      "type": "character|scene|prop|ui|other",
      "kind": "speaking|non_speaking",
      "voiceDesc": "英文音色描述，仅 speaking",
      "textDesc": "英文外观描述",
      "note": "一句话说明",
      "firstAppear": "首次出现的片段标题"
    }
  ]
}`
    },
    {
      role: 'user',
      content: `请拆解以下故事，并登记其中的实体：\n\n${story}`
    }
  ]
}

/* ---------------- 只梳理实体（不拆片段） ---------------- */

export function buildEntityExtractMessages(
  story: string,
  knownEntityNames: string[]
): ChatMessage[] {
  return [
    {
      role: 'system',
      content: `${BASE_SYSTEM}

现在是【实体梳理】。只做一件事：把故事里出现过的实体完整登记出来。

规则：
1. 覆盖到角色、场景、道具、界面四类。不要遗漏只在背景里出现的场景。
2. 会说话的角色 kind 填 speaking，并给出英文 voiceDesc（形如 "speaking with a mature male voice, lazy and arrogant"），不带 (Sx) 后缀。
3. 不说话的实体 kind 填 non_speaking，不写 voiceDesc，改为尽量给出 textDesc（英文外观描述）。
4. 每个实体给一句话 note 说明用途，并给 firstAppear 说明首次出现在哪。
5. 已知实体不要重复输出。

已知实体：
${knownEntityNames.length ? knownEntityNames.join('、') : '（暂无）'}

输出 JSON 结构：
{
  "newEntities": [
    { "name": "", "type": "character|scene|prop|ui|other", "kind": "speaking|non_speaking",
      "voiceDesc": "", "textDesc": "", "note": "", "firstAppear": "" }
  ]
}`
    },
    {
      role: 'user',
      content: `故事原文：\n\n${story}`
    }
  ]
}

/* --------------------------- 阶段二 --------------------------- */

export interface Stage2BeatDetail {
  id: string
  entities: string[]
  speaker?: string
  focus?: string
  direction?: string
  visualDesc?: string
  scene?: string
}

export function buildStage2Messages(
  beats: Beat[],
  entities: Entity[],
  options: { fps?: number } = {}
): ChatMessage[] {
  const entityTable = entities
    .map((e) => {
      const parts = [
        `- name: ${e.name}`,
        `type: ${e.type}`,
        `kind: ${e.kind}`,
        e.pictureN != null ? `picture: <Picture ${e.pictureN}>` : 'picture: 无（纯文本描述）',
        e.voiceDesc ? `voice: ${e.voiceDesc}` : '',
        e.textDesc ? `visual: ${e.textDesc}` : ''
      ].filter(Boolean)
      return parts.join(' | ')
    })
    .join('\n')

  const beatTable = beats
    .map((b) => {
      const base = [`id: ${b.id}`, `kind: ${b.kind}`, `title: ${b.title}`]
      if (b.kind === 'dialogue') base.push(`dialogue: ${b.dialogue ?? ''}`)
      return `- ${base.join(' | ')}`
    })
    .join('\n')

  return [
    {
      role: 'system',
      content: `${BASE_SYSTEM}

现在是【阶段二：细节填充】。
任务：为每个已确认的 Beat 补充镜头细节与实体绑定。

硬性要求：
1. 只做"补全与细化"，不要推翻已有信息：
   - 若某个 Beat 已经给出了实体绑定，entities 与 speaker 必须原样返回，不得替换；
   - 只有在它为空时才由你补全。
2. entities 必须是已知实体名单中的 name，用数组给出，至少 1 个，不能为空。
3. dialogue 类型的 Beat 的 speaker 必须是 kind 为 speaking 的实体，并出现在 entities 里。
4. focus 是本镜头聚焦的主体（一般是 speaker；非台词镜头取画面中心主体）。
5. scene 填该 Beat 所处场景实体名（kind 为 scene 或场景类实体）。
6. direction 写景别与运镜，英文，简短，例如 "medium shot, slow push in"。
7. visualDesc 写画面内容，英文，简短，描述保留参考图中的哪些特征。
8. 不得引入名单外的实体；不得改动 Beat 的 kind 与顺序；不得编造新剧情。
9. 必须为每一个输入的 Beat id 返回一条结果，id 原样返回。

已知实体名单：
${entityTable || '（无）'}

输出 JSON 结构：
{
  "details": [
    {
      "id": "与输入一致的 beat id",
      "entities": ["实体名"],
      "speaker": "实体名，非台词片段省略",
      "focus": "实体名",
      "scene": "实体名",
      "direction": "英文镜头描述",
      "visualDesc": "英文画面描述"
    }
  ]
}`
    },
    {
      role: 'user',
      content: `需要填充的 Beat 列表：\n\n${beatTable}`
    }
  ]
}

/* --------------------------- 阶段三 --------------------------- */

export interface SegmentFillInput {
  schema: FieldSchema[]
  /** 已素材化的片段序列（含 preshoot / tail_cut / black） */
  groupBeats: Beat[]
  entities: Entity[]
  seamFromPrev: SeamAnalysis | null
  nextSeam: SeamAnalysis | null
  /** 已有字段：派生字段已由引擎算好，作为只读上下文交给模型，不给它改 */
  existing: Record<string, string>
  segmentIndex: number
  segmentTotal: number
  frames: number
  fps: number
}

/** 每个字段的写作要求，优先于 Schema 里的 promptHint */
const FIELD_RULES: Record<string, string> = {
  summary: `必须以字面量 [reference generation] 开头（含方括号），紧接着用 2-4 句英文概述本段：谁、在哪、做了什么、结果如何。必须点明主体保留自哪张参考图，例如 <Subject 1> is retained from <Picture 1>。不得重复台词原文，不得出现 leave / disappear / fade out 这类反向叙事表述。`,
  overall_soundscape: `1-4 句英文，描写环境声、物理动作声、非语言人声（呼吸、脚步、衣物摩擦）。不得重复任何对白原文，不得描写配乐。`,
  non_diegetic_music: `无配乐时只填 N/A（三个字符）。有配乐则用 1-3 句英文描述乐器、速度、节奏与情绪走向。`
}

/**
 * 阶段三：为一个已经组合定稿的视频段补全需要模型填写的字段。
 * 只请求 schema 中 source === 'llm' 的字段，derived 字段作为只读上下文给出。
 */
export function buildSegmentFillMessages(input: SegmentFillInput): ChatMessage[] {
  const { schema, groupBeats, entities, existing, segmentIndex, segmentTotal, frames, fps } = input

  const entityById = new Map(entities.map((e) => [e.id, e]))
  const nameOf = (id?: string | null) => (id ? entityById.get(id)?.name ?? '' : '')

  const targets = [...schema].sort((a, b) => a.order - b.order).filter((f) => f.source === 'llm')
  const targetKeys = new Set(targets.map((f) => f.key))

  const duration = (frames / fps).toFixed(3)
  const dialogueCount = groupBeats.filter((b) => b.kind === 'dialogue').length

  const usedIds = new Set<string>()
  for (const b of groupBeats) {
    for (const id of b.entities ?? []) usedIds.add(id)
    if (b.speakerId) usedIds.add(b.speakerId)
  }
  const entityBrief = [...usedIds]
    .map((id) => entityById.get(id))
    .filter((e): e is Entity => !!e)
    .sort((a, b) => (a.subjectN ?? 999) - (b.subjectN ?? 999))
    .map((e) => {
      const src =
        e.pictureN != null
          ? `参考图 <Picture ${e.pictureN}>`
          : '无参考图，按 subject_definitions 的文本描述'
      const voice = e.voiceDesc ? `音色：${e.voiceDesc}` : '不说话'
      const tag = `${subjectTag(e)}${e.sx != null ? ` ${sxTag(e)}` : ''}`
      return `- ${tag} ${e.name} — ${src}；${voice}`
    })
    .join('\n')

  const structure = groupBeats
    .map((b, i) => {
      const who = nameOf(b.speakerId) || nameOf(resolveSubjectId(b)) || '—'
      const body = b.kind === 'dialogue' ? `says: ${b.dialogue ?? ''}` : b.visualDesc || b.title
      return `${String(i + 1).padStart(2, '0')}. [${BEAT_KIND_LABEL[b.kind]}] ${who} — ${body}`
    })
    .join('\n')

  const seamBrief = (seam: SeamAnalysis | null, which: 'prev' | 'next'): string => {
    if (!seam) return which === 'prev' ? '本段是第一段，无前接。' : '本段是最后一段，无后接。'
    if (which === 'prev') {
      if (seam.blackFallback) return '上一段最后一帧为黑屏，本段自行决定开头。'
      return seam.needsPreshoot
        ? '上段结尾与本段首个说话主体一致，本段开头有 0.3 秒说话人独占预备镜头。'
        : '上段与本段直接顺接。'
    }
    if (seam.blackFallback) return '本段最后一帧黑屏，下段自行决定开头。'
    return seam.needsTailCut
      ? `本段最后 0.3 秒切镜至 ${nameOf(seam.tailCutTargetId)}。`
      : '本段结尾与下段主体一致，直接顺接。'
  }

  // 派生字段作为只读上下文，帮模型对齐镜头与主体，但不允许它改写
  const derivedContext = Object.entries(existing)
    .filter(([k, v]) => v && !targetKeys.has(k))
    .map(([k, v]) => `【${k}】\n${v}`)
    .join('\n\n')

  const targetList = targets
    .map((f) => `- ${f.key}：${FIELD_RULES[f.key] ?? f.promptHint ?? f.label}`)
    .join('\n')

  const jsonShape = JSON.stringify(Object.fromEntries(targets.map((f) => [f.key, ''])), null, 2)

  return [
    {
      role: 'system',
      content: `${BASE_SYSTEM}

现在是【阶段三：视频段字段补全】。
分段已经组合定稿，镜头顺序、时间轴、主体绑定都不可更改。
你的任务只有一件：为这一段补全下面列出的字段。

硬性要求：
1. 只输出要求你生成的字段。其余字段是只读上下文，不要重复输出、不要改写。
2. 除 <d> 标签内的中文台词外，全部使用英文。
3. 不得编造镜头序列里不存在的信息。
4. 输出必须是合法 JSON，不要输出任何解释文字或 Markdown 代码块标记。

各字段的写作要求：
${targetList || '-（没有需要生成的字段）'}

输出 JSON 结构：
${jsonShape}`
    },
    {
      role: 'user',
      content: `【段信息】
第 ${segmentIndex + 1} / ${segmentTotal} 段
${frames} 帧 = ${duration} 秒
共 ${groupBeats.length} 拍，其中说话镜头 ${dialogueCount} 个

【段首衔接】${seamBrief(input.seamFromPrev, 'prev')}
【段尾衔接】${seamBrief(input.nextSeam, 'next')}

【出场实体与参考图】
${entityBrief || '-（无）'}

【本段镜头序列】
${structure}
${derivedContext ? `\n【已生成字段（只读，不要重复输出）】\n${derivedContext}` : ''}

请只生成这些字段：${targets.map((f) => f.key).join('、') || '（无）'}`
    }
  ]
}
